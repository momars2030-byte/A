const run=document.getElementById("run"), statusEl=document.getElementById("status"), body=document.getElementById("rows"), limits=document.getElementById("limits");
const fmt=(v,n=2)=>v===null||v===undefined||!Number.isFinite(Number(v))?"—":Number(v).toFixed(n);
run.addEventListener("click",async()=>{
 const symbols=document.getElementById("symbols").value.trim();
 if(!symbols){statusEl.textContent="أدخل رمز سهم واحداً على الأقل.";return;}
 run.disabled=true;statusEl.textContent="جارٍ جلب البيانات وتحليلها…";body.innerHTML="";
 try{
  const r=await fetch(`/api/scan?symbols=${encodeURIComponent(symbols)}`), data=await r.json();
  if(!r.ok) throw new Error(data.error||"حدث خطأ.");
  for(const x of data.results){
   const tr=document.createElement("tr");
   if(x.error||x.excluded){tr.innerHTML=`<td>${x.symbol}</td><td colspan="7" class="bad">${x.error||x.reason}</td>`;}
   else tr.innerHTML=`<td>${x.symbol}</td><td>$${fmt(x.price)}</td><td>${fmt(x.rsi,1)}</td><td>$${fmt(x.support)}</td><td>${fmt(x.distanceFromLowPct,1)}%</td><td>${x.dailyTrend}</td><td>${x.fourHourState}</td><td class="score">${x.score}/100</td>`;
   body.appendChild(tr);
  }
  limits.textContent=data.limitation||"";
  statusEl.textContent=`اكتمل الفحص. وقت الطلب: ${new Date(data.asOf).toLocaleString("ar-SA")}`;
 }catch(e){statusEl.textContent=e.message;body.innerHTML='<tr><td colspan="8">تعذر إكمال الفحص.</td></tr>';}
 finally{run.disabled=false;}
});