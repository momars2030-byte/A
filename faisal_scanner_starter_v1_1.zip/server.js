import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.TWELVE_DATA_API_KEY;

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

async function td(params) {
  if (!API_KEY) throw new Error("لم تتم إضافة مفتاح Twelve Data إلى إعدادات الخادم.");
  const url = new URL("https://api.twelvedata.com/time_series");
  for (const [k,v] of Object.entries({...params, apikey: API_KEY})) url.searchParams.set(k, v);
  const r = await fetch(url);
  const j = await r.json();
  if (!r.ok || j.status === "error" || j.code) throw new Error(j.message || "تعذر جلب البيانات.");
  return j;
}
function num(v) { return Number(v); }
function rsi(closes, period=14) {
  if (closes.length <= period) return null;
  let gains=0, losses=0;
  for(let i=1;i<=period;i++){const d=closes[i]-closes[i-1]; if(d>0) gains+=d; else losses-=d;}
  let ag=gains/period, al=losses/period;
  for(let i=period+1;i<closes.length;i++){
    const d=closes[i]-closes[i-1];
    ag=(ag*(period-1)+Math.max(d,0))/period;
    al=(al*(period-1)+Math.max(-d,0))/period;
  }
  if(al===0) return 100;
  return 100-(100/(1+ag/al));
}
function ema(values, period) {
  if(values.length<period) return null;
  const k=2/(period+1);
  let e=values.slice(0,period).reduce((a,b)=>a+b,0)/period;
  for(const v of values.slice(period)) e=v*k+e*(1-k);
  return e;
}
function analyze(series) {
  const rows=(series.values||[]).slice().reverse();
  const c=rows.map(x=>num(x.close)).filter(Number.isFinite);
  const lows=rows.map(x=>num(x.low)).filter(Number.isFinite);
  const last=c.at(-1);
  return {
    last,
    rsi14:rsi(c),
    ema20:ema(c,20),
    ema50:ema(c,50),
    support20:lows.length?Math.min(...lows.slice(-20)):null,
    low52w:lows.length?Math.min(...lows.slice(-Math.min(252,lows.length))):null,
    bars:rows.length,
    latestBar:rows.at(-1)?.datetime
  };
}
app.get("/api/scan", async (req,res)=>{
  try {
    const symbols=String(req.query.symbols||"").toUpperCase().split(/[,\s]+/).filter(Boolean).slice(0,8);
    if(!symbols.length) return res.status(400).json({error:"أدخل رمز سهم واحداً على الأقل."});
    const results=[];
    for(const symbol of symbols){
      try{
        const [d,h]=await Promise.all([
          td({symbol, interval:"1day", outputsize:260, order:"ASC"}),
          td({symbol, interval:"4h", outputsize:100, order:"ASC"})
        ]);
        const daily=analyze(d), fourHour=analyze(h);
        if(!daily.last || daily.last<1 || daily.last>6) {
          results.push({symbol, excluded:true, reason:"السعر خارج نطاق 1–6 دولارات", price:daily.last});
          continue;
        }
        const nearLow=daily.low52w ? ((daily.last/daily.low52w)-1)*100 : null;
        const dailyTrend=daily.ema20!==null && daily.ema50!==null ? (daily.last>daily.ema20?"فوق EMA20":"تحت EMA20") : "بيانات غير كافية";
        const fourHourState=fourHour.ema20!==null ? (fourHour.last>fourHour.ema20?"فوق EMA20":"تحت EMA20") : "بيانات غير كافية";
        let score=0;
        if(nearLow!==null && nearLow<=10) score+=30;
        if(daily.rsi14!==null && daily.rsi14<40) score+=10;
        if(daily.ema20!==null && daily.last>daily.ema20) score+=15;
        if(fourHour.ema20!==null && fourHour.last>fourHour.ema20) score+=20;
        if(fourHour.ema20!==null && fourHour.ema50!==null && fourHour.ema20>fourHour.ema50) score+=25;
        results.push({symbol,price:daily.last, rsi:daily.rsi14, support:daily.support20, low52w:daily.low52w, distanceFromLowPct:nearLow, dailyTrend, fourHourState, score, dailyBars:daily.bars, fourHourBars:fourHour.bars, latestBar:daily.latestBar, note:"درجة الجاهزية إرشادية أولية؛ لا تمثل تأكيد BOS/CHoCH أو تحقق هدف الدورة."});
      }catch(e){results.push({symbol,error:e.message});}
    }
    res.json({asOf:new Date().toISOString(), results, limitation:"المسح الحالي يفحص الرموز التي تدخلها فقط، وبحد أقصى 8 رموز في الطلب. لا يكتشف جميع أسهم السوق ولا التقسيمات العكسية تلقائياً."});
  }catch(e){res.status(500).json({error:e.message});}
});
app.get("/api/status",(req,res)=>res.json({configured:Boolean(API_KEY)}));
app.listen(PORT,()=>console.log(`Scanner running on ${PORT}`));
